package com.spark.assistant;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView statusText;
    private EditText commandInput;
    private Button sendButton;
    private Button connectButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        statusText = findViewById(R.id.statusText);
        commandInput = findViewById(R.id.commandInput);
        sendButton = findViewById(R.id.sendButton);
        connectButton = findViewById(R.id.connectButton);

        // Set up click listeners
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String command = commandInput.getText().toString().trim();
                if (!command.isEmpty()) {
                    sendCommand(command);
                    commandInput.setText("");
                }
            }
        });

        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectToWindows();
            }
        });

        // Initial status
        updateStatus("Disconnected. Press Connect to pair with Windows.");
    }

    private void sendCommand(String command) {
        // In a real implementation, this would send the command to the Windows app
        // For this simplified version, we'll just show a toast
        Toast.makeText(this, "Command sent: " + command, Toast.LENGTH_SHORT).show();
        updateStatus("Command sent: " + command);
    }

    private void connectToWindows() {
        // In a real implementation, this would initiate discovery and connection
        // For this simplified version, we'll just update the status
        updateStatus("Searching for Windows device...");
        
        // Simulate connection after a delay
        connectButton.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateStatus("Connected to Windows device");
                Toast.makeText(MainActivity.this, "Connected to Windows device", Toast.LENGTH_SHORT).show();
            }
        }, 2000);
    }

    private void updateStatus(String status) {
        statusText.setText(status);
    }
}
