# Spark AI Assistant Mobile App - Build & Usage Guide

This guide provides step-by-step instructions for building and using the simplified Spark AI Assistant mobile companion app.

## Overview

The Spark AI Assistant mobile companion app allows you to:
- Connect to the Spark AI Assistant running on your Windows device
- Send commands from your phone to your Windows computer
- Receive responses and notifications from your Windows computer

## Building the APK with GitHub Actions

### Step 1: Create a GitHub Account
If you don't already have one, create a free GitHub account at [github.com](https://github.com/).

### Step 2: Create a New Repository
1. Click the "+" icon in the top-right corner of GitHub and select "New repository"
2. Name your repository (e.g., "SparkAssistantMobile")
3. Make it public or private (your choice)
4. Click "Create repository"

### Step 3: Upload the Project Files
1. On your new repository page, click "uploading an existing file"
2. Upload all files and folders from the SparkAssistantMobile directory
3. Make sure to maintain the directory structure:
   - app/ (directory with all app files)
   - .github/workflows/build-android.yml

### Step 4: Run the GitHub Actions Workflow
1. After uploading, click on the "Actions" tab in your repository
2. You should see the "Build Android APK" workflow
3. Click "Run workflow" and confirm by clicking the green "Run workflow" button
4. The workflow will start building your APK (this takes 3-5 minutes)

### Step 5: Download the APK
1. Once the workflow completes (green checkmark), click on the completed run
2. Scroll down to the "Artifacts" section
3. Click on "spark-assistant-debug" to download the APK file

### Step 6: Install on Your Android Device
1. Transfer the APK to your Android device via:
   - Email
   - USB cable
   - Cloud storage (Google Drive, Dropbox)
2. On your Android device, open the APK file
3. If prompted, enable "Install from Unknown Sources" in settings
4. Follow the on-screen instructions to complete installation

## Using the Spark AI Assistant Mobile App

### Connecting to Windows
1. Make sure the Spark AI Assistant is running on your Windows computer
2. Open the Spark Assistant app on your Android device
3. Tap the "Connect to Windows" button
4. Wait for the connection to be established
5. Once connected, the status will update to "Connected to Windows device"

### Sending Commands
1. After connecting, type your command in the text field
2. Tap the "Send Command" button
3. The command will be sent to your Windows computer
4. You'll see a confirmation message on your phone

### Example Commands
- "What time is it?"
- "Open Chrome"
- "Turn up the volume"
- "Send a message to John"

## Troubleshooting

### Connection Issues
- Ensure both devices are on the same Wi-Fi network
- Check that the Windows app is running
- Try restarting both the Windows app and mobile app

### Installation Problems
- Make sure "Install from Unknown Sources" is enabled
- Check that your Android version is compatible (Android 8.0+)
- Ensure you have enough storage space on your device

### Build Failures
If the GitHub Actions workflow fails:
1. Check the workflow logs for specific error messages
2. Ensure all files were uploaded with the correct structure
3. Try running the workflow again

## Next Steps

This is a simplified version of the Spark AI Assistant mobile companion app. For the full-featured version with complete functionality, refer to the main project documentation.
